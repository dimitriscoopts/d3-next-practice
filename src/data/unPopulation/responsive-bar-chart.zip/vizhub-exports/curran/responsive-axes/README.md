A viz container with responsive axes that have consistent
tick mark density. Try
[opening in full screen mode](https://vizhub.com/curran/8a596d3b83374cceaa320d0e00127d98?mode=embed)
and resizing!

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/1TfQZhLBQfc?si=7iDvBZasaTwQWU67" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>

# Challenge

- Use this technique to make the axes on your viz responsive
