Data from
[UN Population Estimates 2024](https://population.un.org/wpp/Download/Standard/MostUsed/),
manually filtered to contain only data for 2024.

# Challenge

- Visualize this dataset in a new way
