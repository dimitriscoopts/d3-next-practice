A responsive bar chart.

<iframe width="560" height="315" src="https://www.youtube-nocookie.com/embed/-uQQoYk0EjE?si=2Gu9Lb5kbsVCOles" title="YouTube video player" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share" allowfullscreen></iframe>
